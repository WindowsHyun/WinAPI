#pragma comment(lib, "msimg32.lib")

#include <windows.h>
#include <stdio.h>
#include <time.h>
#include "resource.h"

LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
HINSTANCE g_hInst;

#define isGameCloudY 66 //22�� �ϸ� ����Ʈ
#define isGameCloudX 5
#define isRabitJumpDistance 13

// ���� ������ ������ �������鼭 ��������
// �׿� �ٸ��� ������ ������ �ö󰣴�..!

int isGameCloud[isGameCloudY][isGameCloudX];
int isCreateCloudNum =0, isCheck=0, isMoveCloud =5, isMoveCloudDistance=1, isRabitJump = isRabitJumpDistance;
int isScore = 0, isRealScore[7], isCloudColor =1;
int isGameState = 0; // 0 = StartPage, 1 = Start, 2 = Multi-Play, 3 = GameOver
int isSuperMode =0, isStartTime =0, isEndTime =0, isSuperJump =0;

void isGameFirstStart();
void isCloudMove();
void isRandCloud();

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
	g_hInst=hInstance;
	HWND 	hwnd;
	MSG 		msg;
	WNDCLASS	WndClass; 
	WndClass.style 	= CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc	= WndProc;		
	WndClass.cbClsExtra	= 0;		
	WndClass.cbWndExtra	= 0;		
	WndClass.hInstance 	= hInstance;		
	WndClass.hIcon	= LoadIcon(NULL, "IDI_ICON1");
	WndClass.hCursor 	= LoadCursor(NULL, IDC_ARROW);	
	WndClass.hbrBackground	= (HBRUSH)GetStockObject(BLACK_BRUSH);	
	WndClass.lpszMenuName	= NULL;		
	WndClass.lpszClassName 	= "CrageneRabbit";	
	RegisterClass(&WndClass);	
	hwnd = CreateWindow("CrageneRabbit", "Cragene Rabbit", WS_OVERLAPPEDWINDOW,300, 0, 480, 750, NULL, NULL, hInstance, NULL );
	// 1366*768 �� �ִ�ȭ�� �⺻ ���� ȭ�� 480*800 ũ�� ������ �ȸ����� ����..!
	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);	
		DispatchMessage(&msg);	
	}   
	return (int)msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd,UINT iMsg,WPARAM wParam,LPARAM lParam)
{

	HDC hdc,mem0dc ,mem1dc, mem2dc, mem3dc, mem4dc, mem5dc, mem6dc, isNumber[7], isScoreHdc;
	static HBITMAP isBackgroung, isCharacterLJump[3],  isCharacterRJump[3], isPlay[2], isMultiPlay[2], isExit[2], isCloud, isCloudBlack, isPause;
	static HBITMAP isGameOver, isGetNumber[10], isScoreHbit, isCloudTransparent, isTotalTime, isPoint, isSecond, isRestart[2], isMenu[2];
	static HBITMAP isCloudOrange, isCloudRed, isMarskCloud, isMarskTransparentCloud, isMaskPause, isCharcterHighJump, isMaskCharcterHighJump;
	static HBITMAP isMaskCharacterLJump[3],  isMaskCharacterRJump[3], isMaskNumber, isMaskScore, isMaskTotalTime, isMaskPoint, isMaskSecond;
	HBITMAP hbmOld, hbmMem, hbmMemOld;
	BITMAP isImageSize;
	PAINTSTRUCT ps; 
	HPEN hPen, oldPen;
	static RECT rt, isClickExit, isClickMultiPlay, isClickPlay, isRabbit, isJumpCloud, isClickRestart, isClickMenu;
	static char debug[500];
	static int isBackGroundY = 0;
	static int isRabbitLR=0, isRabbitState=0, isJump=0; // Defalut Left = 0
	static int isX=370, isY=545, mWidth, mHeight;
	static int isGameoverY =0;
	static int isCloudMouseMove[5], isClickCloud=0;
	int bx, by, mx, my;

	switch(iMsg){

	case WM_LBUTTONDOWN:
		mx=LOWORD(lParam);
		my=HIWORD(lParam);

		if( isGameState == 0 ){
			if( mx >= isClickExit.left && mx <= isClickExit.right && my >= isClickExit.top && my<= isClickExit.bottom){
				wsprintf(debug,"������ �����մϴ�..!");
				MessageBox(hwnd,debug,"",CB_OKAY);
				KillTimer(hwnd,1);
				KillTimer(hwnd,2);
				KillTimer(hwnd,3);
				KillTimer(hwnd,4);
				PostQuitMessage(0);
			}else 	if( mx >= isClickMultiPlay.left && mx <= isClickMultiPlay.right && my >= isClickMultiPlay.top && my<= isClickMultiPlay.bottom){
				//MultiPlay ��ư�� Ŭ���� ���Ӹ�带 �����մϴ�..!
				isGameState=2;
			}else 	if( mx >= isClickPlay.left && mx <= isClickPlay.right && my >= isClickPlay.top && my<= isClickPlay.bottom){
				//Play ��ư�� Ŭ���� ���Ӹ�带 �����մϴ�..!
				isGameFirstStart();
				isGameState=1;
				KillTimer(hwnd,1);
				KillTimer(hwnd,2);
				KillTimer(hwnd,3);
				isX=220, isY=605;
				isJump=0;
				isRabbitState=0;
				isMoveCloud =5, isMoveCloudDistance=1, isRabitJump = isRabitJumpDistance, isCheck =0, isScore = 0;
				isStartTime = GetTickCount();
				SetTimer(hwnd,1,10,NULL);
				SetTimer(hwnd,2,35,NULL);
				SetTimer(hwnd,4,10,NULL); 
			}
		}else if( isGameState == 3 ){

			if( mx >= isClickRestart.left && mx <= isClickRestart.right && my >= isClickRestart.top && my<= isClickRestart.bottom){
				isGameFirstStart();
				isGameState=1;
				KillTimer(hwnd,1);
				KillTimer(hwnd,2);
				KillTimer(hwnd,3);
				isX=220, isY=605;
				isScore = 0;
				isRabbitState=0;
				isStartTime = GetTickCount();
				isMoveCloud =5, isMoveCloudDistance=1, isRabitJump = isRabitJumpDistance, isCheck =0, isScore = 0;
				SetTimer(hwnd,1,10,NULL);
				SetTimer(hwnd,2,35,NULL);
				SetTimer(hwnd,4,10,NULL); 
			}else 	if( mx >= isClickMenu.left && mx <= isClickMenu.right && my >= isClickMenu.top && my<= isClickMenu.bottom){
				isGameState=0;
			}

		}
		break;

	case WM_MOUSEMOVE:
		mx=LOWORD(lParam);
		my=HIWORD(lParam);
		if( isGameState == 0 ){
			if( mx >= isClickExit.left && mx <= isClickExit.right && my >= isClickExit.top && my<= isClickExit.bottom){
				isCloudMouseMove[2] = 1;
			}else{
				isCloudMouseMove[2] = 0;
			}

			if( mx >= isClickMultiPlay.left && mx <= isClickMultiPlay.right && my >= isClickMultiPlay.top && my<= isClickMultiPlay.bottom){
				isCloudMouseMove[1] = 1;
			}else{
				isCloudMouseMove[1] = 0;
			}

			if( mx >= isClickPlay.left && mx <= isClickPlay.right && my >= isClickPlay.top && my<= isClickPlay.bottom){
				isCloudMouseMove[0] = 1;
			}else{
				isCloudMouseMove[0] = 0;
			}
		}else if( isGameState == 3 ){
			if( mx >= isClickRestart.left && mx <= isClickRestart.right && my >= isClickRestart.top && my<= isClickRestart.bottom){
				isCloudMouseMove[3] = 1;
			}else{
				isCloudMouseMove[3] = 0;
			}
			if( mx >= isClickMenu.left && mx <= isClickMenu.right && my >= isClickMenu.top && my<= isClickMenu.bottom){
				isCloudMouseMove[4] = 1;
			}else{
				isCloudMouseMove[4] = 0;
			}

		}
		break;

	case WM_KEYDOWN :
		if(wParam == VK_RIGHT){
			isRabbitLR =1;
		}else if(wParam == VK_LEFT){
			isRabbitLR=0;
		}
		break;

	case WM_CHAR:
		if(wParam == 'j' || wParam == 'J'){
			if( isSuperMode == 1){
				isSuperMode =0;
			}else{
				isSuperMode =1;
			}
		}
		break;

	case WM_TIMER:
		switch(wParam){

		case 1:
			if( isGameState == 0 || isGameState == 3){
				isBackGroundY+=2;
			}
			if(isBackGroundY >= rt.bottom){
				isBackGroundY=0;
			}
			isRabbit.left = isX, isRabbit.top = isY, isRabbit.bottom = isY+73, isRabbit.right = isX+66;
			if( isGameState == 1 &&  isRabbit.top <= (rt.bottom/2)+50 ){
				isBackGroundY+=1;
				isCloudMove();
				if( isSuperMode != 1){
					isY+=2;
				}
			}

			if ( isSuperMode == 1){
					if( isSuperJump >= 300){
						isSuperMode=0;
						isSuperJump=0;
					}
					isSuperJump++;
				}

			if( isRabbit.bottom >= rt.bottom+100 &&  isGameState == 1){
				//���� ����..!
				isEndTime = GetTickCount();
				isGameState = 3;
				isX=370, isY=545;
				KillTimer(hwnd,4);
			}
			break;

		case 2:
			if(  rt.bottom/2 <= isRabbit.bottom){
				isY-=10;
			}
			isJump++;
			if(isRabbitState != 2){
				isRabbitState++;
			}
			if(isJump>=isRabitJump && isSuperMode == 0){
				isJump=0;
				isRabbitState=0;
				SetTimer(hwnd,3,35,NULL);
				KillTimer(hwnd,2);
			}
			isRabbit.left = isX, isRabbit.top = isY, isRabbit.bottom = isY+73, isRabbit.right = isX+66;
			break;

		case 3:
			isY+=10;
			isJump++;
			if(isRabbitState != 1){
				isRabbitState++;
			}
			if( isGameState == 0 || isGameState == 3 ){
				if(isJump>=isRabitJump){
					isJump=0;
					isRabbitState=0;
					SetTimer(hwnd,2,35,NULL);
					KillTimer(hwnd,3);
				}
			}
			isRabbit.left = isX, isRabbit.top = isY, isRabbit.bottom = isY+73, isRabbit.right = isX+66;

			if( isGameState == 1 ){
				isBackGroundY-=2;
				for( int i=0; i<isGameCloudX; ++i){
					for(int j=0; j<isGameCloudY; ++j){
						if ( isGameCloud[j][i]  == 1 || isGameCloud[j][i]  == 2 || isGameCloud[j][i]  == 4 || isGameCloud[j][i]  == 5 ){

							bx = rt.right, by = rt.bottom;
							isRabbit.left = isX, isRabbit.top = isY, isRabbit.bottom = isY+73, isRabbit.right = isX+66;
							isJumpCloud.left = bx/isGameCloudX*i, isJumpCloud.top = by/isGameCloudY*j, isJumpCloud.right = (bx/isGameCloudX*i)+100, isJumpCloud.bottom = (by/isGameCloudY*j)+40;

							if( isRabbit.bottom <= by/isGameCloudY*(j+4) &&  isRabbit.bottom >= by/isGameCloudY*j && (bx/isGameCloudX*i)-30 <= isRabbit.left &&  (bx/isGameCloudX*i)+120 >= isRabbit.right ){
								if( j !=0){

									if(isGameCloud[j][i]  == 1){
										isGameCloud[j][i]  = 2;
									}else if(isGameCloud[j][i]  == 2){
										isGameCloud[j][i]  = 3;
									}

									if(isGameCloud[j][i]  == 4){
										int randX = 2;
										srand(isCheck%GetTickCount()+rand()%isCheck);
										randX =	rand()%isGameCloudX;
										isGameCloud[j][i]  = 0;
										isGameCloud[j][randX]  = 5;
									}else if(isGameCloud[j][i]  == 5){
										//Jump
										isSuperJump =0;
										isSuperMode =1;
									}

								}
								isScore++;
								isJump=0;
								isRabbitState=0;
								isClickCloud =1;
								KillTimer(hwnd,3);
								SetTimer(hwnd,2,35,NULL);
								break;
							}else{
								isClickCloud=0;
							}
						}


					}
				}
			}
			break;

		case 4:
			if(isRabbitLR == 1){
				isX+=3;
				if(isX>rt.right){
					isX=rt.left;
					isRabbitLR == 1;
				}
			}else{
				isX-=3;
				if(isX<rt.left){
					isX=rt.right;
					isRabbitLR == 0;
				}
			}
			isRabbit.left = isX, isRabbit.top = isY, isRabbit.bottom = isY+73, isRabbit.right = isX+66;
			break;

		}
		InvalidateRgn(hwnd, NULL, FALSE);
		break;

	case WM_CREATE:
		GetClientRect(hwnd,&rt);
		SetTimer(hwnd,1,10,NULL);
		SetTimer(hwnd,2,35,NULL);
		//SetTimer(hwnd,4,10,NULL); �¿� �����̱�
		/*wsprintf(debug,"top : %d, left : %d, right : %d, bottom : %d",rt.top,rt.left,rt.right,rt.bottom );
		MessageBox(hwnd,debug,"",CB_OKAY);*/
		isBackgroung = (HBITMAP)LoadBitmap(((LPCREATESTRUCT)lParam)->hInstance, MAKEINTRESOURCE(IDB_BITMAP2)); // ���ȭ��
		isCharacterLJump[0] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP3));
		isCharacterLJump[1] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP4));
		isCharacterLJump[2] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP5));
		isMaskCharacterLJump[0] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP42));
		isMaskCharacterLJump[1] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP43));
		isMaskCharacterLJump[2] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP44));
		isCharacterRJump[0] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP6));
		isCharacterRJump[1] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP7));
		isCharacterRJump[2] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP8));
		isMaskCharacterRJump[0] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP45));
		isMaskCharacterRJump[1] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP46));
		isMaskCharacterRJump[2] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP47));
		isPlay[0] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP9));
		isPlay[1] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP15));
		isMultiPlay[0] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP10));
		isMultiPlay[1] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP14));
		isExit[0] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP11));
		isExit[1] =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP13));
		isCloud =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP12));
		isPause = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP16));
		isCloudBlack = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP17));
		isGameOver = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP18));
		isGetNumber[0] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP19));
		isGetNumber[1] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP20));
		isGetNumber[2] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP21));
		isGetNumber[3] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP22));
		isGetNumber[4] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP23));
		isGetNumber[5] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP24));
		isGetNumber[6] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP25));
		isGetNumber[7] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP26));
		isGetNumber[8] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP27));
		isGetNumber[9] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP28));
		isScoreHbit = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP29));
		isCloudTransparent = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP30));
		isTotalTime = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP31));
		isPoint =  LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP32));
		isSecond = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP33));
		isRestart[0] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP34));
		isRestart[1] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP35));
		isMenu[0] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP36));
		isMenu[1] = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP37));
		isCloudOrange = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP38));
		isCloudRed = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP39));
		isMarskCloud = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP40));
		isMarskTransparentCloud = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP41));
		isMaskNumber = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP48));
		isMaskScore = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP49));
		isMaskTotalTime = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP50));
		isMaskPoint = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP51));
		isMaskSecond = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP52));
		isMaskPause = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP53));
		isCharcterHighJump  = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP54));
		isMaskCharcterHighJump  = LoadBitmap(g_hInst,MAKEINTRESOURCE(IDB_BITMAP55));
		isClickExit.left = 10, isClickExit.top = 415, isClickExit.bottom = 500, isClickExit.right = 350;
		isClickMultiPlay.left = 120, isClickMultiPlay.top = 245, isClickMultiPlay.bottom = 335, isClickMultiPlay.right = 464;
		isClickPlay.left = 10, isClickPlay.top = 85,  isClickPlay.bottom = 175, isClickPlay.right = 350;
		isRabbit.left = 240, isRabbit.top = 535, isRabbit.bottom = 608, isRabbit.right = 305;
		isClickRestart.left =10, isClickRestart.top = 450, isClickRestart.bottom = 540, isClickRestart.right = 350;
		isClickMenu.left = 120, isClickMenu.top = 580, isClickMenu.bottom = 675, isClickMenu.right = 460;
		isCloudMouseMove[0] = 0, isCloudMouseMove[1] = 0, isCloudMouseMove[2] = 0;
		isCloudMouseMove[3] = 0, isCloudMouseMove[4] = 0;
		break;

	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);

		mem0dc = CreateCompatibleDC(hdc);//2
		hbmMem = CreateCompatibleBitmap(hdc, rt.right, rt.bottom);//3
		hbmMemOld = (HBITMAP)SelectObject(mem0dc, hbmMem);//4

		if( isGameState == 0 ){
			mem1dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem1dc, isBackgroung);//6
			bx = rt.right, by = rt.bottom;
			StretchBlt(mem0dc,0,isBackGroundY-by, bx, by,mem1dc,0,0,472,723,SRCCOPY);
			StretchBlt(mem0dc,0,isBackGroundY, bx, by,mem1dc,0,0,472,723,SRCCOPY);
			sprintf(debug, "isX : %d, isY : %d", isX, isY);
			TextOut(mem0dc, 0,0, debug, strlen(debug));
			SelectObject(mem1dc, hbmOld);//-6
			DeleteDC(mem1dc);//-5

			//-----------------------------------------------------------------------------------------------------------------------------------------------------
			mem2dc = CreateCompatibleDC(mem0dc);//5
			if( isRabbitLR == 0){
				hbmOld = (HBITMAP)SelectObject(mem2dc, isMaskCharacterLJump[isRabbitState]);//6
				GetObject (isMaskCharacterLJump[isRabbitState], sizeof(BITMAP), &isImageSize);
			}else{
				hbmOld = (HBITMAP)SelectObject(mem2dc, isMaskCharacterRJump[isRabbitState]);//6
				GetObject (isMaskCharacterRJump[isRabbitState], sizeof(BITMAP), &isImageSize);
			}
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,isX,isY, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem2dc, hbmOld);//-6
			DeleteDC(mem2dc);//-5
			//�䳢 ���� ����
			mem2dc = CreateCompatibleDC(mem0dc);//5
			if( isRabbitLR == 0){
				hbmOld = (HBITMAP)SelectObject(mem2dc, isCharacterLJump[isRabbitState]);//6
				GetObject (isCharacterLJump[isRabbitState], sizeof(BITMAP), &isImageSize);
			}else{
				hbmOld = (HBITMAP)SelectObject(mem2dc, isCharacterRJump[isRabbitState]);//6
				GetObject (isCharacterRJump[isRabbitState], sizeof(BITMAP), &isImageSize);
			}
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,isX,isY, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem2dc, hbmOld);//-6
			DeleteDC(mem2dc);//-5
			//-----------------------------------------------------------------------------------------------------------------------------------------------------
			mem3dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem3dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,10,80, mWidth-50, mHeight-50,mem3dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem3dc, hbmOld);//-6
			DeleteDC(mem3dc);//-5
			// Play ��ư
			mem3dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem3dc, isPlay[isCloudMouseMove[0]]);//6
			GetObject (isPlay[isCloudMouseMove[0]], sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,10,80, mWidth-50, mHeight-50,mem3dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem3dc, hbmOld);//-6
			DeleteDC(mem3dc);//-5
			//-----------------------------------------------------------------------------------------------------------------------------------------------------
			mem4dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem4dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,120,240, mWidth-50, mHeight-50,mem4dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem4dc, hbmOld);//-6
			DeleteDC(mem4dc);//-5
			//��Ƽ�÷��� ��ư
			mem4dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem4dc, isMultiPlay[isCloudMouseMove[1]]);//6
			GetObject (isMultiPlay[isCloudMouseMove[1]], sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,120,240, mWidth-50, mHeight-50,mem4dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem4dc, hbmOld);//-6
			DeleteDC(mem4dc);//-5
			//-----------------------------------------------------------------------------------------------------------------------------------------------------
			mem5dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem5dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,10,410, mWidth-50, mHeight-50,mem5dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem5dc, hbmOld);//-6
			DeleteDC(mem5dc);//-5
			//Exit ��ư
			mem5dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem5dc, isExit[isCloudMouseMove[2]]);//6
			GetObject (isExit[isCloudMouseMove[2]], sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,10,410, mWidth-50, mHeight-50,mem5dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem5dc, hbmOld);//-6
			DeleteDC(mem5dc);//-5
			//-----------------------------------------------------------------------------------------------------------------------------------------------------
			mem6dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem6dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,350,610, mWidth-300, mHeight-120,mem6dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem6dc, hbmOld);//-6
			DeleteDC(mem6dc);//-5
			// ��������
			mem6dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem6dc, isCloud);//6
			GetObject (isCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,350,610, mWidth-300, mHeight-120,mem6dc,0,0,mWidth,mHeight,SRCPAINT);//
			SelectObject(mem6dc, hbmOld);//-6
			DeleteDC(mem6dc);//-5
			//-----------------------------------------------------------------------------------------------------------------------------------------------------
		}else if( isGameState == 1 ){
			// Play ��忡���� ���� ���

			mem1dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem1dc, isBackgroung);//6
			bx = rt.right, by = rt.bottom;
			StretchBlt(mem0dc,0,isBackGroundY-by, bx, by,mem1dc,0,0,472,723,SRCCOPY);
			StretchBlt(mem0dc,0,isBackGroundY, bx, by,mem1dc,0,0,472,723,SRCCOPY);
			/*sprintf(debug, "Left : %d, Right : %d, Top : %d, Bottom : %d / %d", isRabbit.left , isRabbit.right, isRabbit.top, isRabbit.bottom, isCheck);
			TextOut(mem0dc, 0,rt.bottom-40, debug, strlen(debug));
			sprintf(debug, "isMoveCloudDistance : %d, isRabitJump : %d", isMoveCloudDistance, isRabitJump);
			TextOut(mem0dc, 0,rt.bottom-20, debug, strlen(debug));*/
			//		if( isCheck >= 250*isMoveCloudDistance){
			//isRabitJump+=2;

			//isJumpCloud.left = bx/isGameCloudX*i, isJumpCloud.top = by/isGameCloudY*j, isJumpCloud.right = (bx/isGameCloudX*i)+94, isJumpCloud.bottom = (by/isGameCloudY*j)+40;
			/*	for( int i=0; i<isGameCloudX; ++i){
			for(int j=0; j<isGameCloudY; ++j){
			sprintf(debug, "%d", isGameCloud[j][i]);
			TextOut(mem0dc, 20+(i*10),10+(j*10), debug, strlen(debug));
			}
			}*/
			SelectObject(mem1dc, hbmOld);//-6
			DeleteDC(mem1dc);//-5

			//----------------------------------------------------------------------------------------------------------------------------------------------------
			// Score �Է� �κ� isScoreHbit
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isScoreHbit);//6
			GetObject (isScoreHbit, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, 0, rt.bottom-40, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5

			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isMaskScore);//6
			GetObject (isMaskScore, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, 0,  rt.bottom-40, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5

			for(int i=0; i<7; ++i){
				isRealScore[i]=0;
			}

			int i=6, tempScore = isScore, isStartData=6;

			while(tempScore!=0){
				// ���ڸ� ����� �迭�� �ִ´�..!
				isRealScore[i] = tempScore%10;
				i--;
				tempScore=tempScore/10;
			}
			for(int i=0; i<7; ++i){
				if(isRealScore[i] != 0){
					isStartData = i;
					break;
				}
			}

			for(int i=isStartData; i<7; ++i){
				isNumber[i] = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(isNumber[i], isGetNumber[isRealScore[i]]);//6
				GetObject (isGetNumber[isRealScore[i]], sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc, 120+(i*17), rt.bottom-39, mWidth-20, mHeight, isNumber[i],0,0,mWidth,mHeight,SRCAND);
				SelectObject(isNumber[i], hbmOld);//-6
				DeleteDC(isNumber[i]);//-5
				//���� ���
				isNumber[i] = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(isNumber[i], isMaskNumber);//6
				GetObject (isMaskNumber, sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc, 120+(i*17), rt.bottom-39, mWidth-20, mHeight, isNumber[i],0,0,mWidth,mHeight,SRCPAINT);
				SelectObject(isNumber[i], hbmOld);//-6
				DeleteDC(isNumber[i]);//-5
			}
			//----------------------------------------------------------------------------------------------------------------------------------------------------
			if( isSuperMode == 1){

				mem2dc = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(mem2dc, isMaskCharcterHighJump);//6
				GetObject (isMaskCharcterHighJump, sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc,isX,isY, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCAND);
				SelectObject(mem2dc, hbmOld);//-6
				DeleteDC(mem2dc);//-5
				//�䳢 ���� ����
				mem2dc = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(mem2dc, isCharcterHighJump);//6
				GetObject (isCharcterHighJump, sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc,isX,isY, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCPAINT);
				SelectObject(mem2dc, hbmOld);//-6
				DeleteDC(mem2dc);//-5

			}else{
				mem2dc = CreateCompatibleDC(mem0dc);//5
				if( isRabbitLR == 0){
					hbmOld = (HBITMAP)SelectObject(mem2dc, isMaskCharacterLJump[isRabbitState]);//6
					GetObject (isMaskCharacterLJump[isRabbitState], sizeof(BITMAP), &isImageSize);
				}else{
					hbmOld = (HBITMAP)SelectObject(mem2dc, isMaskCharacterRJump[isRabbitState]);//6
					GetObject (isMaskCharacterRJump[isRabbitState], sizeof(BITMAP), &isImageSize);
				}
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc,isX,isY, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCAND);
				SelectObject(mem2dc, hbmOld);//-6
				DeleteDC(mem2dc);//-5
				//�䳢 ���� ����
				mem2dc = CreateCompatibleDC(mem0dc);//5
				if( isRabbitLR == 0){
					hbmOld = (HBITMAP)SelectObject(mem2dc, isCharacterLJump[isRabbitState]);//6
					GetObject (isCharacterLJump[isRabbitState], sizeof(BITMAP), &isImageSize);
				}else{
					hbmOld = (HBITMAP)SelectObject(mem2dc, isCharacterRJump[isRabbitState]);//6
					GetObject (isCharacterRJump[isRabbitState], sizeof(BITMAP), &isImageSize);
				}
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc,isX,isY, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCPAINT);
				SelectObject(mem2dc, hbmOld);//-6
				DeleteDC(mem2dc);//-5
			}
			//----------------------------------------------------------------------------------------------------------------------------------------------------
			/*
			#define isGameCloudY 20
			#define isGameCloudX 10
			*/

			//mem4dc = CreateCompatibleDC(mem0dc);//5
			//hbmOld = (HBITMAP)SelectObject(mem4dc, isCloud);//6
			//GetObject (isCloud, sizeof(BITMAP), &isImageSize);
			//mWidth = isImageSize.bmWidth;
			//mHeight = isImageSize.bmHeight;
			//TransparentBlt(mem0dc, 350, 610, mWidth-300, mHeight-120, mem4dc, 0, 0,mWidth, mHeight, RGB(255, 0, 0) );
			//SelectObject(mem4dc, hbmOld);//-6
			//DeleteDC(mem4dc);//-5
			//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			for( int i=0; i<isGameCloudX; ++i){
				for(int j=0; j<isGameCloudY; ++j){
					if ( isGameCloud[j][i]  == 1 || isGameCloud[j][i]  == 2 || isGameCloud[j][i]  == 3 || isGameCloud[j][i]  == 4  || isGameCloud[j][i]  == 5 ){
						mem6dc = CreateCompatibleDC(mem0dc);//5
						//isMarskTransparentCloud
						if ( isGameCloud[j][i]  == 3 ){
							hbmOld = (HBITMAP)SelectObject(mem6dc, isMarskTransparentCloud);//6
						}else{
							hbmOld = (HBITMAP)SelectObject(mem6dc, isMarskCloud);//6
						}
						GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
						mWidth = isImageSize.bmWidth;
						mHeight = isImageSize.bmHeight;
						StretchBlt(mem0dc,bx/isGameCloudX*i,by/isGameCloudY*j, mWidth-300, mHeight-120,mem6dc,0,0,mWidth,mHeight,SRCAND);
						SelectObject(mem6dc, hbmOld);//-6
						DeleteDC(mem6dc);//-5
						// ��������
						mem6dc = CreateCompatibleDC(mem0dc);//5
						if ( isGameCloud[j][i]  == 1 ){
							hbmOld = (HBITMAP)SelectObject(mem6dc, isCloud);//6
						}else if ( isGameCloud[j][i]  == 2 ){
							hbmOld = (HBITMAP)SelectObject(mem6dc, isCloudBlack);//6
						}else if ( isGameCloud[j][i]  == 3 ){
							hbmOld = (HBITMAP)SelectObject(mem6dc, isCloudTransparent);//6
						}else if ( isGameCloud[j][i]  == 4 ){
							hbmOld = (HBITMAP)SelectObject(mem6dc, isCloudOrange);//6
						}else if ( isGameCloud[j][i]  == 5 ){
							hbmOld = (HBITMAP)SelectObject(mem6dc, isCloudRed);//6
						}
						GetObject (isCloud, sizeof(BITMAP), &isImageSize);
						mWidth = isImageSize.bmWidth;
						mHeight = isImageSize.bmHeight;
						StretchBlt(mem0dc,bx/isGameCloudX*i,by/isGameCloudY*j, mWidth-300, mHeight-120,mem6dc,0,0,mWidth,mHeight,SRCPAINT);
						SelectObject(mem6dc, hbmOld);//-6
						DeleteDC(mem6dc);//-5

					}
				}
			}
			//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			mem2dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem2dc, isPause);//6
			GetObject (isPause, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right-mWidth+20, rt.bottom-40, mWidth-20, mHeight, mem2dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem2dc, hbmOld);//-6
			DeleteDC(mem2dc);//-5
			//isMaskPause
			mem2dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem2dc, isMaskPause);//6
			GetObject (isMaskPause, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right-mWidth+20, rt.bottom-40, mWidth-20, mHeight, mem2dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem2dc, hbmOld);//-6
			DeleteDC(mem2dc);//-5



		}else if( isGameState == 2 ){
			//Ƽ �÷��� ������ �κ�..!
			isGameState = 1;
			/*
			��Ƽ�÷��̵� �Ϲ��÷��̶� ������ �ڵ带 ����ϹǷ� ���� ������Ʈ�� Ȯ���� �Ͽ� 
			���� ������ �ش� ������ ����Ͽ� �񱳸� �Ҽ��ְ� �����..!
			���� ó�� ���� �ҽ��ڵ带 �߰����� ����..!
			*/
		}else if( isGameState == 3 ){
			//GameOver..!
			mem1dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem1dc, isBackgroung);//6
			bx = rt.right, by = rt.bottom;
			StretchBlt(mem0dc,0,isBackGroundY-by, bx, by,mem1dc,0,0,472,723,SRCCOPY);
			StretchBlt(mem0dc,0,isBackGroundY, bx, by,mem1dc,0,0,472,723,SRCCOPY);
			SelectObject(mem1dc, hbmOld);//-6
			DeleteDC(mem1dc);//-5

			//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			mem2dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem2dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/13, 30, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem2dc, hbmOld);//-6
			DeleteDC(mem2dc);//-5
			//GameOver
			mem2dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem2dc, isGameOver);//6
			GetObject (isGameOver, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/13, 30, mWidth, mHeight,mem2dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem2dc, hbmOld);//-6
			DeleteDC(mem2dc);//-5
			//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isScoreHbit);//6
			GetObject (isScoreHbit, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/4, 240, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			// Score
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isMaskScore);//6
			GetObject (isMaskScore, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/4,  240, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			for(int i=0; i<7; ++i){
				isRealScore[i]=0;
			}

			int i=6, tempScore = isScore,  isStartData=6;

			while(tempScore!=0){
				// ���ڸ� ����� �迭�� �ִ´�..!
				isRealScore[i] = tempScore%10;
				i--;
				tempScore=tempScore/10;
			}

			for(int i=0; i<7; ++i){
				if(isRealScore[i] != 0){
					isStartData = i;
					break;
				}
			}

			for(int i=isStartData; i<7; ++i){
				isNumber[i] = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(isNumber[i], isGetNumber[isRealScore[i]]);//6
				GetObject (isGetNumber[isRealScore[i]], sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc, rt.right/4+120+(i*17), 240, mWidth-20, mHeight, isNumber[i],0,0,mWidth,mHeight,SRCAND);
				SelectObject(isNumber[i], hbmOld);//-6
				DeleteDC(isNumber[i]);//-5
				//���� ���
				isNumber[i] = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(isNumber[i], isMaskNumber);//6
				GetObject (isMaskNumber, sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc, rt.right/4+120+(i*17), 240, mWidth-20, mHeight, isNumber[i],0,0,mWidth,mHeight,SRCPAINT);
				SelectObject(isNumber[i], hbmOld);//-6
				DeleteDC(isNumber[i]);//-5
			}
			// isMaskPoint
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isPoint);//6
			GetObject (isPoint, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,rt.right/4+123+(7*17), 240, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			//��
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isMaskPoint);//6
			GetObject (isMaskPoint, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc,rt.right/4+123+(7*17), 240, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isTotalTime);//6
			GetObject (isTotalTime, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/26, 320, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			// TotalTime
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isMaskTotalTime);//6
			GetObject (isMaskTotalTime, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/26,  320, mWidth, mHeight, isScoreHdc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

			int isPlayTime = (isEndTime-isStartTime)/1000;

			for(int i=0; i<7; ++i){
				isRealScore[i]=0;
			}

			i=6, tempScore = isPlayTime, isStartData=6;
			while(tempScore!=0){
				// ���ڸ� ����� �迭�� �ִ´�..!
				isRealScore[i] = tempScore%10;
				i--;
				tempScore=tempScore/10;
			}

			for(int i=0; i<7; ++i){
				if(isRealScore[i] != 0){
					isStartData = i;
					break;
				}
			}

			for(int i=isStartData; i<7; ++i){
				isNumber[i] = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(isNumber[i], isGetNumber[isRealScore[i]]);//6
				GetObject (isGetNumber[isRealScore[i]], sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc, rt.right/4+120+(i*17), 320, mWidth-20, mHeight, isNumber[i],0,0,mWidth,mHeight,SRCAND);
				SelectObject(isNumber[i], hbmOld);//-6
				DeleteDC(isNumber[i]);//-5
				//���� ���
				isNumber[i] = CreateCompatibleDC(mem0dc);//5
				hbmOld = (HBITMAP)SelectObject(isNumber[i], isMaskNumber);//6
				GetObject (isMaskNumber, sizeof(BITMAP), &isImageSize);
				mWidth = isImageSize.bmWidth;
				mHeight = isImageSize.bmHeight;
				StretchBlt(mem0dc, rt.right/4+120+(i*17), 320, mWidth-20, mHeight, isNumber[i],0,0,mWidth,mHeight,SRCPAINT);
				SelectObject(isNumber[i], hbmOld);//-6
				DeleteDC(isNumber[i]);//-5
			}

			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isSecond );//6
			GetObject (isSecond, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/4+123+(7*17), 321, mWidth-7, mHeight,isScoreHdc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			//isMaskSecond
			isScoreHdc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(isScoreHdc, isMaskSecond );//6
			GetObject (isMaskSecond, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, rt.right/4+123+(7*17), 321, mWidth-7, mHeight,isScoreHdc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(isScoreHdc, hbmOld);//-6
			DeleteDC(isScoreHdc);//-5
			//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			mem3dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem3dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, 10, 450, mWidth-50, mHeight-50, mem3dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem3dc, hbmOld);//-6
			DeleteDC(mem3dc);//-5
			//Restart
			mem3dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem3dc, isRestart[isCloudMouseMove[3]] );//6
			GetObject (isRestart[isCloudMouseMove[3]], sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, 10, 450, mWidth-50, mHeight-50,mem3dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem3dc, hbmOld);//-6
			DeleteDC(mem3dc);//-5
			//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
			mem3dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem3dc, isMarskCloud);//6
			GetObject (isMarskCloud, sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, 120, 580, mWidth-50, mHeight-50, mem3dc,0,0,mWidth,mHeight,SRCAND);
			SelectObject(mem3dc, hbmOld);//-6
			DeleteDC(mem3dc);//-5
			//Menu
			mem3dc = CreateCompatibleDC(mem0dc);//5
			hbmOld = (HBITMAP)SelectObject(mem3dc, isMenu[isCloudMouseMove[4]] );//6
			GetObject (isMenu[isCloudMouseMove[4]], sizeof(BITMAP), &isImageSize);
			mWidth = isImageSize.bmWidth;
			mHeight = isImageSize.bmHeight;
			StretchBlt(mem0dc, 120, 580, mWidth-50, mHeight-50, mem3dc,0,0,mWidth,mHeight,SRCPAINT);
			SelectObject(mem3dc, hbmOld);//-6
			DeleteDC(mem3dc);//-5
			//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		}

		BitBlt(hdc, 0, 0, rt.right, rt.bottom, mem0dc, 0, 0, SRCCOPY);
		//-------------------------------------------------------------------------------------------------------------
		/*hPen = CreatePen(PS_DOT, 2, RGB(255,255,255));
		oldPen = (HPEN)SelectObject(hdc, hPen);
		for(int i=1; i<(isGameCloudX); ++i){
		MoveToEx(hdc, rt.right/(isGameCloudX)*i, rt.top,NULL);
		LineTo(hdc, rt.right/(isGameCloudX)*i,rt.bottom);
		}
		for(int i=0; i<=isGameCloudY; ++i){
		if(i ==0){
		MoveToEx(hdc, rt.left,0,NULL);
		LineTo(hdc, rt.right,0);
		}else{
		MoveToEx(hdc, rt.left,rt.bottom/(isGameCloudY)*i,NULL);
		LineTo(hdc, rt.right,rt.bottom/(isGameCloudY)*i);
		}
		}
		SelectObject(hdc,oldPen);
		DeleteObject(hPen);*/
		//-------------------------------------------------------------------------------------------------------------
		SelectObject(mem0dc, hbmMemOld); //-4
		DeleteObject(hbmMem); //-3
		DeleteObject(hbmMemOld); //-3
		DeleteDC(mem0dc); //-2
		DeleteDC(hdc); //-2
		break;

	case WM_DESTROY:
		KillTimer(hwnd,1);
		KillTimer(hwnd,2);
		KillTimer(hwnd,3);
		KillTimer(hwnd,4);
		PostQuitMessage(0);
		break;
	}
	return(DefWindowProc(hwnd,iMsg,wParam,lParam));
}

void isGameFirstStart(){
	int randX =0;
	int isReData[2];
	//srand(GetTickCount()%rand()%1000);
	srand((unsigned int)time(NULL));

	isReData[0] = -1;
	isReData[1] = -1;
	isMoveCloud =5, isMoveCloudDistance=1, isRabitJump = isRabitJumpDistance, isCheck =0, isCreateCloudNum =0;

	for(int i=0; i<isGameCloudY; ++i){
		for(int j=0; j<isGameCloudX; ++j){
			isGameCloud[i][j] = 0;
		}
	}

	for(int i=0; i<isGameCloudY; i++){
		isCreateCloudNum++;


		if(isCreateCloudNum == isMoveCloud){
			isCreateCloudNum =0;
			randX = rand()%isGameCloudX;
			if(isReData[1] == randX){
				while(1){
					if(isReData[1] != randX && randX <= isGameCloudX){
						break;
					}
					randX = rand()%isGameCloudX;
				}
				isGameCloud[i][randX] = 1;
				isReData[0] = i;
				isReData[1] = randX;
			}else{
				isGameCloud[i][randX] = 1;
				isReData[0] = i;
				isReData[1] = randX;
			}
		}
	}

	for(int i=0; i<isGameCloudX; ++i){
		isGameCloud[64][i] = 2;
	}
}

void isCloudMove(){
	int isNext =0;
	int isArrT[5];
	int randX =0;
	int isReData=0;

	srand((unsigned int)time(NULL));

	for( int i=isGameCloudY-1; i>-1; --i){
		isNext = i;
		isNext -=1;

		if( i != 0 && isNext != -1 ){

			for(int j=0; j<isGameCloudX; ++j){
				isArrT[j] = isGameCloud[isNext][j];
			}
			for(int j=0; j<isGameCloudX; ++j){
				isGameCloud[i][j] = isArrT[j];
			}

		}else{
			for(int j=0; j<isGameCloudX; ++j){
				isGameCloud[0][randX] = 0;
			}

			//-----------------------------------------------------------------------------------

			randX = rand()%isGameCloudX;
			isCreateCloudNum++;
			isCheck++;
			isScore++;
			//isScore=isMoveCloudDistance;

			if( isCheck >= 250*isMoveCloudDistance){
				if( isRabitJump <= 40){
					isRabitJump+=2;
				}
				isMoveCloud++;
				isMoveCloudDistance++;
			}
			if(isCreateCloudNum == isMoveCloud){
				isCreateCloudNum =0;
				//Sleep(1);
				srand(isCheck%GetTickCount()+rand()%isCheck);
				randX = rand()%isGameCloudX;
				if(isReData == randX){
					while(1){
						if(isReData != randX ){
							break;
						}
						//Sleep(1);
						srand(isCheck%GetTickCount()+rand()%isCheck);
						randX = rand()%isGameCloudX;
					}
					if( rand()%10 == 3){
						randX = 0;
					}
					isRandCloud();
					isGameCloud[1][randX] = isCloudColor;
					isReData = randX;
				}else{
					if( rand()%10 == 4){
						randX = 0;
					}
					isRandCloud();
					isGameCloud[1][randX] = isCloudColor;
					isReData = randX;
				}
			}
			//-----------------------------------------------------------------------------------
		}

	}

}

void isRandCloud(){
	// 1 = �Ϲݱ���, 2 = ȸ������, 3= �����ѱ���, 4 = ��Ȳ������, 5= ������ ����
	//Sleep(1);
	srand(isCheck%GetTickCount()+rand()%isCheck);
	if(isCheck >= 300){
		if(rand()%5 == 3){
			isCloudColor =2; 
		}else if(rand()%5 == 4){
			isCloudColor =4;
		}else{
			isCloudColor=1;
		}
	}else if(isCheck >= 500){
		if(rand()%5 == 4){
			isCloudColor =2;
		}else if(rand()%5 == 2){
			isCloudColor =4;
		}else{
			isCloudColor=1;
		}
	}else if(isCheck >= 1200){
		if(rand()%4 == 2){
			isCloudColor =2;
		}else if(rand()%4 == 3){
			isCloudColor =4;
		}else{
			isCloudColor=1;
		}
	}else if(isCheck >= 2100){
		if(rand()%3 == 1){
			isCloudColor =2;
		}else if(rand()%3 == 2){
			isCloudColor =4;
		}else{
			isCloudColor=1;
		}
	}else if(isCheck >= 4200){
		if(rand()%2 == 1){
			isCloudColor =2;
		}else if(rand()%2 == 1){
			isCloudColor =4;
		}else{
			isCloudColor=1;
		}
	}else{
		isCloudColor=1;
	}
}